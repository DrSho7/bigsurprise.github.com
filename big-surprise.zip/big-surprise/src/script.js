const pressBtn = document.getElementById('pressBtn');
const timer = document.getElementById('timer');
const message = document.getElementById('message');
const alarmSound = document.getElementById('alarmSound');

pressBtn.addEventListener('click', () => {
  pressBtn.classList.add('hidden');
  timer.classList.remove('hidden');
  timer.classList.add('show');

  let countdown = 5;
  timer.textContent = `Timer: ${countdown} seconds`;

  const interval = setInterval(() => {
    countdown--;
    if (countdown > 0) {
      timer.textContent = `Timer: ${countdown} seconds`;
    } else {
      clearInterval(interval);
      timer.classList.remove('show');
      timer.classList.add('hidden');

      // Show final message
      message.classList.remove('hidden');
      message.classList.add('show', 'bounce');
      message.textContent = 'You Are All Data Got Hacked By Dr Sho';
      message.style.color = '#ff3333';
      message.style.textShadow = '0 0 20px #ff3333';

      // Play sound effect
      alarmSound.play();
    }
  }, 1000);
});